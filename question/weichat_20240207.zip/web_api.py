import random

import uvicorn
import os
import re
import logging.handlers
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from message_hander import signature, signature2, repsone_gpt, encrypt_replying_messages, extracte_info, approval_process_message
from send_app import qywx
from mysql.crud import get_task_info_by_applicant, modify_approval_result
from mysql.database import SessionLocal

mysql = SessionLocal()

app = FastAPI()
qy = qywx()

# Config logs file
if not os.path.exists("static"):
    os.makedirs("static")
# Config logs file
if not os.path.exists("logs"):
    os.makedirs("logs")
# ################生产要修改#####################
log_level = logging.INFO
# #######################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(log_level)
# 添加TimedRotatingFileHandler
timefilehandler = logging.handlers.TimedRotatingFileHandler(
    "logs/weichat.log",  # 日志路径
    when='D',  # S秒 M分 H时 D天 W周 按时间切割 测试选用S
    encoding='utf-8'
)
# 设置后缀名称，跟strftime的格式一样
timefilehandler.suffix = "%Y-%m-%d_%H-%M-%S.log"
formatter = logging.Formatter(
    "%(asctime)s | %(pathname)s | %(funcName)s | %(lineno)s | %(levelname)s - %(message)s", "%Y-%m-%d %H:%M:%S")
timefilehandler.setFormatter(formatter)
logger.addHandler(timefilehandler)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],

)


@app.get("/")
def index():
    return "welcome to navigation fastapi"


@app.get("/weichat")
def get_weichat(request: Request):
    msg_signature = request.query_params.get("msg_signature")
    timestamp = request.query_params.get("timestamp")
    nonce = request.query_params.get("nonce")
    echostr = request.query_params.get("echostr", )
    sEchoStr = signature(msg_signature, timestamp, nonce, echostr)
    if sEchoStr == "failed":
        return "get_weichat: 解密失败"
    else:
        echo_str = int(sEchoStr.decode("utf-8").replace("\"","").replace("\n", ""))
        return echo_str


@app.post("/weichat")
async def post_weichat(request: Request):
    logger.info(f"request_url: {request.url}")
    msg_signature = request.query_params.get("msg_signature")
    timestamp = request.query_params.get("timestamp")
    nonce = request.query_params.get("nonce")
    request_body = await request.body()
    data = request_body.decode("utf-8")
    logger.info(f"request_body: {data}")
    type_xml, sMsg = signature2(msg_signature, timestamp, nonce, data)
    key_info, from_user, msg_id = extracte_info(sMsg, type_xml)
    # TODO: 测试用的
    oa_account = "guoyf2"
    if type_xml == "failed":
        return encrypt_replying_messages(from_user, "signature2解密失败，请上报给管理者", msg_id, nonce, timestamp)
    elif sMsg == "审批请求":
        # TODO: 1.返回该用户的task_id, task_name, user集合， 2.保存在redis/pg 在确认请求中，重新抓sql获取
        # 通过userid得到申请人的oa
        # oa_account = qy.get_oa_account(from_user)
        # 再通过orm 查询未审批&正常状态的任务
        querys = get_task_info_by_applicant(mysql, oa_account)
        # 助手只展示前20条的任务列表
        content = approval_process_message(querys)
        return encrypt_replying_messages(from_user, content, msg_id, nonce, timestamp)
    elif re.match(r"审批请求确认", sMsg):
        # oa_account = qy.get_oa_account(from_user)  # TODO: 测试时注释先
        taskids = None
        keyword = None
        if sMsg == "审批请求确认":
            pass
        elif re.match(r"审批请求确认(\s*\d+)+$", sMsg):
            taskids = re.split(r"\s+", sMsg.replace("审批请求确认", "").strip())
        elif re.match(r"审批请求确认只包含(\w+)$", sMsg):
            keyword = sMsg.replace("审批请求确认只包含", "")
        else:
            return encrypt_replying_messages(from_user, "请确认好回复的规则。", msg_id, nonce, timestamp)
        querys = get_task_info_by_applicant(mysql, oa_account, taskids=taskids, keyword=keyword)
        if len(querys) == 0:
            return encrypt_replying_messages(from_user, "匹配的审批请求为空", msg_id, nonce, timestamp)
        qy.send_text(f"审批校验中....", [from_user])
        result = random.sample([1, 0], 1)[0]
        task_ids = ",".join([row.task_id for row in querys])
        if result == 1:
            # 成功返回给当事人，跟转发给admin
            admin_user_id = "17a755177f4ad1f1d99bf8042cfbb74a"
            qy.send_text(f"校验成功，已转发给zhangzh4", [from_user])
            qy.send_text(f"{oa_account}发起的审批请求单号{random.randint(0,99)}:\ntask_ids: {task_ids}校验成功，请你执行审阅", [admin_user_id])
        else:
            # 失败返回给当事人
            qy.send_text(f"校验失败，请仔细修改", [from_user])
        # TODO: 发送需校验的task_name, 以及检验需要的信息
        # TODO : 校验功能待开发
    elif sMsg == "审批通过":
        # 判断其是否为admin
        # 判断其名下审批单pg下的内容 task_ids
        task_ids = [""]
        admin = ""
        modify_approval_result(mysql, task_ids, admin, 1)
        pass
    elif sMsg == "审批不通过：":
        # 判断其是否为admin
        # 判断其名下审批单
        task_ids = [""]
        admin = ""
        modify_approval_result(mysql, task_ids, admin, 0)
        pass

    elif sMsg == "我是管理员":
        # TODO: 为管理员增加userid
        oa_account = qy.get_oa_account(from_user)
        pass
    elif type_xml == "text":
        content = key_info
        content = repsone_gpt(content)
        resp_xml = encrypt_replying_messages(from_user, content, msg_id, nonce, timestamp)
    elif type_xml in ["file", "image"]:
        media_id = key_info
        resp_xml = encrypt_replying_messages(from_user, f"暂时只支持文本回复{type_xml}", msg_id, nonce, timestamp)
        qy.download_file(media_id)
        # TODO: 功能后续处理
    else:
        resp_xml = encrypt_replying_messages(sMsg,"暂时只支持文本回复", msg_id, nonce, timestamp)
    return resp_xml


if __name__ == "__main__":
    import os
    PORT = os.getenv("PORT")
    WORKERS = os.getenv("WORKERS")
    # PORT = 10051
    # WORKERS = 2
    assert PORT is not None
    assert WORKERS is not None
    uvicorn.run("web_api:app", host='0.0.0.0', port=int(PORT), workers=int(WORKERS))
